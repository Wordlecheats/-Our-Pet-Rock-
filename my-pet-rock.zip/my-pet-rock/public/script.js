const rock = document.getElementById('rock');
const rockNameInput = document.getElementById('rock-name');
const rockSizeDisplay = document.getElementById('rock-size');
const saveButton = document.getElementById('save-customizations');

// Load rock data
let rockData = {
  name: 'Rocky',
  color: '#808080',
  size: 1.0,
  lastVisit: new Date().toISOString(),
};

function loadRockData() {
  fetch('/api/rock-data')
    .then((response) => response.json())
    .then((data) => {
      rockData = data;
      updateRock();
    });
}

// Update rock properties
function updateRock() {
  const now = new Date();
  const lastVisit = new Date(rockData.lastVisit);
  const timeElapsed = (now - lastVisit) / 1000 ; // minutes

  // Growth logic: grow 0.01% per second
  rockData.size += (timeElapsed * 0.01);
  rockData.lastVisit = now.toISOString();

  // Apply changes
  rock.style.transform = `scale(${rockData.size})`;
  rockNameInput.value = rockData.name;
  rockSizeDisplay.textContent = rockData.size.toFixed(2);

  saveRockData();
}

// Save rock data
function saveRockData() {
  fetch('/api/rock-data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(rockData),
  });
}

// Event listeners for customization
saveButton.addEventListener('click', () => {
  rockData.name = rockNameInput.value || 'Rocky';
  updateRock();
});

// Initialize
loadRockData();
