const express = require('express');
const fs = require('fs');
const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static('public'));
app.use(express.json());

// Endpoint to fetch and update rock data
app.get('/api/rock-data', (req, res) => {
  fs.readFile('./public/rock-data.json', 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: 'Failed to read rock data.' });
    res.json(JSON.parse(data));
  });
});

app.post('/api/rock-data', (req, res) => {
  const newData = JSON.stringify(req.body, null, 2);
  fs.writeFile('./public/rock-data.json', newData, (err) => {
    if (err) return res.status(500).json({ error: 'Failed to save rock data.' });
    res.json({ success: true });
  });
});

app.listen(PORT, () => console.log(`Server is running on http://localhost:${PORT}`));
